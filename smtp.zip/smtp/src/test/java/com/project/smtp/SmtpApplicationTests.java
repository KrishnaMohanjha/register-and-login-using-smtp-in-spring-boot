package com.project.smtp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmtpApplicationTests {

	@Test
	void contextLoads() {
	}

}
